package ass1;



/**
 * @author YinanFeng
 *
 */
public class specRoomOrder {
	private int roomType;
	private int nor;

	
	public specRoomOrder(int roomType, int nor) {
		this.roomType = roomType;
		this.nor = nor;

	}

	public int getRoomType() {
		return this.roomType;
	}

	public int getNor() {
		return this.nor;
	}
	
}
